package com.mevius.kepcocal

import android.content.Intent
import android.os.Bundle
import android.widget.Adapter
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_project_list.*

class ProjectListActivity : AppCompatActivity() {
    var itemDataList = arrayListOf<ProjectListViewItemData>(
        ProjectListViewItemData("삼척지사 절연유 점검", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검1", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검2", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검3", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검4", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검5", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검6", "2020.01.30"),
        ProjectListViewItemData("삼척지사 절연유 점검7", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검8", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검9", "2020.09.30"),
        ProjectListViewItemData("삼척지사 절연유 점검09", "2020.09.30")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project_list)

        supportActionBar?.title = "프로젝트 리스트"    // Set AppBar Title

        val listViewAdapter = ProjectListViewAdapter(this, itemDataList)    // new ListViewAdapter
        lv_project_list.adapter = listViewAdapter   // Set Apapter to Listview in xml
        itemDataList.removeAt(1)
        itemDataList.add(1, ProjectListViewItemData("삼척지사 절연유 점검 123", "2020.09.30"))
//        Toast.makeText(this,ListDataArray[1].toString(), Toast.LENGTH_SHORT).show()
//        Adapter.notifyDataSetChanged()

        lv_project_list.setOnItemClickListener() { parent, view, position, id ->
            val element = listViewAdapter.getItem(position)
            val intent = Intent(this, ProjectDetailActivity::class.java)
            startActivity(intent)
        }

        lv_project_list.setOnItemLongClickListener() { parent, view, position, id ->
            val element = listViewAdapter.getItem(position)
            val intent = Intent(this, ProjectDetailActivity::class.java)
            return true
        }
    }
}