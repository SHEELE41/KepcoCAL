package com.mevius.kepcocal

data class ProjectListViewItemData(var projectName : String, var dateToString : String )